<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Inclure les classes PHPMailer
require 'vendor/autoload.php';

// Vérifier si l'ID de la demande est passé en paramètre dans l'URL
if (isset($_GET['id'])) {
    // Récupérer l'ID de la demande
    $id_demande = $_GET['id'];

    // Connexion à la base de données MySQL
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "limos";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Requête SQL pour sélectionner les informations de la demande à partir de l'ID
    $sql = "SELECT id_utilisateur, id_universite, id_event FROM demande_participation_event WHERE id = $id_demande";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Récupérer les informations de la demande
        $row = $result->fetch_assoc();
        $id_utilisateur = $row['id_utilisateur'];
        $id_universite = $row['id_universite'];
        $id_event = $row['id_event'];

        // Requête SQL pour récupérer les informations de l'utilisateur à partir de son ID
        $sql_info_utilisateur = "SELECT fname, lname, email FROM utilisateur_ins WHERE id = $id_utilisateur";
        $result_info_utilisateur = $conn->query($sql_info_utilisateur);

        if ($result_info_utilisateur->num_rows > 0) {
            // Récupérer l'e-mail de l'utilisateur
            $row_info_utilisateur = $result_info_utilisateur->fetch_assoc();
            $prenom_utilisateur = $row_info_utilisateur['fname'];
            $nom_utilisateur = $row_info_utilisateur['lname'];
            $email_utilisateur = $row_info_utilisateur['email'];


            // Envoyer l'e-mail à l'utilisateur avec PHPMailer
            $mail = new PHPMailer(true); // True enables exceptions

            try {
                // Paramètres du serveur SMTP
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                

                $mail->SMTPAuth   = true;
                $mail->Username   = 'limoslaboratory@gmail.com'; // Votre adresse email Gmail
                $mail->Password   = 'ayzckrijgybjomvq';   // Mot de passe de votre compte Gmail
                $mail->SMTPSecure = 'tls';
                $mail->Port       = 587;

                // Destinataire
                $mail->setFrom('limoslaboratory@gmail.com', 'LIMOSE LABORATORY');
                $mail->addAddress($email_utilisateur);
               

                // Contenu de l'e-mail
                $mail->isHTML(true);
                $mail->Subject = 'ADMIS EVENT ';
                $mail->Body    = "Madame/Monsieur $nom_utilisateur,<br><br>J'ai le plaisir de vous informer que votre demande a été examinée avec attention et a été acceptée. Nous sommes ravis de pouvoir répondre à vos attentes et restons à votre disposition pour toute question complémentaire.<br><br>Cordialement,<br>
                <br>
                <a href=\"http://localhost/panel/st/id.php\">Cliquez ici por telecharger votre card access EVENT</a>
                <br>
                <br>
                <a href=\"https://www.google.com/maps/place/Universit%C3%A9+M'hamed+Bougara+-+Facult%C3%A9+des+sciences/@36.7523247,3.4707379,15z/data=!4m6!3m5!1s0x128e688d16851b83:0xd9b6c88acb9517ba!8m2!3d36.7523247!4d3.4707379!16s%2Fg%2F11f2gshrcq?entry=ttu\"> la localisation de l'evenement</a>";
                
                // Envoyer l'e-mail
                $mail->send();

                // Afficher un message de succès
                echo "<script>alert('E-mail envoyé avec succès.'); window.location.href = 'demande_event.php'; </script>";
            } catch (Exception $e) {
                // Afficher les erreurs s'il y a lieu
                echo "Erreur lors de l'envoi de l'e-mail : {$mail->ErrorInfo}";
            }
        } else {
            echo "L'utilisateur associé à cette demande n'a pas d'adresse e-mail enregistrée.";
        }
    } else {
        echo "Aucune demande trouvée avec cet ID.";
    }

    // Fermer la connexion à la base de données
    $conn->close();
} else {
    echo "ID de demande non spécifié.";
}

?>
