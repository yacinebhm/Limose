<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="shortcut icon" href="assets\imgs\Limose-removebg-preview.png">
    <link rel="stylesheet" href="style1.css">
    <title>Add Limose Event</title>
</head>



<?php
// Vérifier si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les valeurs des champs du formulaire
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $mail = $_POST['mail'];
    $pass = $_POST['pass'];

    // Vérifier si les champs requis sont vides
    if (empty($fname) || empty($lname) || empty($mail) || empty($pass)) {
        echo "<script>alert('Tous les champs sont remplie obligatoires');</script>";
    } else {
        // Connexion à la base de données MySQL
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "limos";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Vérifier la connexion
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Préparer la requête SQL pour insérer les données dans la table
        $sql = "INSERT INTO evenement (titre, description, date_debut, date_fin) VALUES ('$fname', '$lname', '$mail', '$pass')";

        // Exécuter la requête SQL
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Evenement ajouter avec succès.'); window.location.href = 'event.php';</script>";
        } else {
            echo "Erreur lors de l'ajout de l'evenement: " . $conn->error;
        }

        // Fermer la connexion à la base de données
        $conn->close();
    }
}
?>





<body>
    <div class="container">
        <form method="post">
            <div class="box">
                <div class="header">
                    <header><img src="assets\images\limos.jpg" alt=""></header>
                    <p>ADD Limose event</p>
                </div>
                <div class="input-box">
                    <label for="fname">TITLE</label>
                    <input type="text" name="fname" >
                </div>
                <div class="input-box">
                    <label for="lname">DESCRIPTION</label>
                    <input type="text" name="lname" >
                </div>
                <div class="input-box">
                    <label for="mail">DATE START</label>
                    <input type="date" name="mail" >
                    
                </div>
                <div class="input-box">
                    <label for="pass">DATE END</label>
                    <input type="date" name="pass" >
                    
                </div>
                <input type="submit" name="update_user" value="ADD">
            </div>
        </form>
    </div>
</body>

</html>