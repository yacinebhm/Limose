<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="IDCard.css">
    <link rel="stylesheet" href="print.css" media="print">
    <title>ID Card</title>
   
</head>
<body>
    <div class="container">
        <div class="padding">
        <div class="font">
            <div class="companyname">Limose<br><span class="tab">Evenet Card</span></div>
            <div class="top">
                <img src="profil.png" alt="">
            </div>
            <div class="">
                <div class="ename">
                <p class="p1"><b>Yacine Bhm</b></p>
                <p>Teacher</p>
                </div>
                <div class="edetails">
                    <P><b>Mobile No :</b> 0553903506</P>
                    <p><b>DOB :</b> 24/05/2024</p>
                    <div class="Address"><b>Address : </b>223 par-1 hari soc, near main road ,L.H road surat ,L.H road </div>
                    
                </div>

                <div class="signature">
                    <img src="signature.png" alt="">
                </div>

                <div class="barcode">
                    <img src="qr sample.png" alt="">
                </div>
                <div class="qr">
                    <img src="barcode.png" alt="">
                </div>
                
          
            </div>
        </div>
    </div>
       
    </div>
    <button id="printButton" class="print-button" onclick="printCard()">Imprimer</button>


    <script>
        function printCard() {
            // Cacher le bouton d'impression
            document.getElementById("printButton").style.display = "none";

            // Appeler la fonction d'impression de la fenêtre
            window.print();

            // Réafficher le bouton d'impression après l'impression (dans un délai de 1 seconde)
            setTimeout(function() {
                document.getElementById("printButton").style.display = "block";
            }, 1000);
        }
    </script>
</body>
</html>